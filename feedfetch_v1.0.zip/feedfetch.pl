#!/usr/bin/perl
# ===============================================================
# FeedFetch v1.0  (MODULAR + fixed header/body split)
# ===============================================================
# Fetches RSS/Atom/RDF feeds via HTTP/HTTPS, with chunked + gzip
# decoding and robust fallback handling.
# ===============================================================

use strict;
use warnings;
use Socket;
use IO::Socket::INET;
use URI::Escape;

BEGIN { eval { require IO::Socket::SSL; } }

my $VERSION       = "1.0";
my $MAX_ITEMS     = 15;
my $TIMEOUT       = 20;
my $MAX_REDIRECTS = 4;
my $DEBUG         = 'N';   # <-- Default off

my $FONT_FAMILY = "sans-serif";
my $FONT_SIZE   = "10pt";
my $BOX_BORDER  = "1px solid #888";
my $BOX_BG      = "#f8f8f8";
my $BOX_PADDING = "0.6em";
my $BOX_HEIGHT  = "100%";
my $LINK_COLOR  = "#0044aa";
my $LINK_HOVER  = "underline";

print "Content-type: text/html\n\n";
print_debug_banner();

my %P   = parse_query($ENV{'QUERY_STRING'} // '');
my $url = $P{url} // '';
unless ($url) { print "<b>No URL provided.</b>"; exit; }

dlog("FeedFetch v$VERSION");
dlog("URL = $url");

my $xml = fetch_with_fallback($url);
unless ($xml) { print "<p>No data received from $url</p>"; exit; }

$xml =~ s/^\xEF\xBB\xBF//;
(my $peek = $xml) =~ s/^\s+//r;
my $fmt = detect_format($peek);
dlog("Detected format: $fmt");

my ($title, @items);
if    ($fmt eq 'rss')  { ($title,@items)=parse_rss($xml); }
elsif ($fmt eq 'atom') { ($title,@items)=parse_atom($xml); }
elsif ($fmt eq 'rdf')  { ($title,@items)=parse_rdf($xml); }
else {
  dlog("Unknown format; first 300 bytes:\n".substr($peek,0,300));
  print "<p>Unknown feed format.</p>";
  exit;
}

output_html($title,@items);
exit;

sub debug_enabled { return 1 if $DEBUG eq 'Y'; return ($ENV{'QUERY_STRING'}//'') =~ /debug=1/; }

sub print_debug_banner {
  return unless debug_enabled();
  print "<div style='background:#222;color:#eee;padding:6px;font:12px monospace'>[DEBUG ENABLED]</div>\n";
}

sub dlog {
  return unless debug_enabled();
  my ($msg)=@_; $msg//= '';
  $msg =~ s/&/&amp;/g; $msg =~ s/</&lt;/g; $msg =~ s/>/&gt;/g;
  print "<pre style='white-space:pre-wrap;margin:2px 0;'>[DEBUG] $msg</pre>\n";
}

sub parse_query {
  my ($qs)=@_; my %h;
  for my $p (split /&/, $qs) {
    next if $p eq '';
    my ($k,$v)=split /=/,$p,2;
    $k=uri_unescape($k//''); $v=uri_unescape($v//''); $h{$k}=$v;
  }
  return %h;
}

sub fetch_with_fallback {
  my ($url)=@_;
  my $body = fetch_http($url,0,http10_hint($url));
  if(!$body && $url =~ /^http:/i) {
    (my $https=$url)=~s/^http:/https:/i;
    dlog("Retry HTTPS: $https");
    $body = fetch_http($https,0,http10_hint($https));
  }
  return $body;
}

sub http10_hint {
  my ($url)=@_;
  my (undef,$host)=$url=~m|^(https?)://([^/]+)|i;
  return 1 if $host =~ /(rss\.slashdot\.org|slashdot\.org|theregister\.co\.uk|register\.co\.uk)/i;
  return 0;
}

sub fetch_http {
  my ($url,$depth,$force_http10)=@_;
  return "" if $depth > $MAX_REDIRECTS;

  my ($proto,$host,$path)=$url=~m|^(https?)://([^/]+)(/.*)?$|i;
  return "" unless $host;
  my $is_https = ($proto && lc$proto eq 'https') ? 1 : 0;
  my $port     = $is_https ? 443 : 80;
  $path ||= '/';
  my $http_proto = $force_http10 ? "HTTP/1.0" : "HTTP/1.1";

  dlog("Fetching $url via $http_proto");

  my $sock;
  if($is_https){
    $sock = IO::Socket::SSL->new(
      PeerHost=>$host,
      PeerPort=>$port,
      Timeout=>$TIMEOUT,
      SSL_hostname=>$host,
      SSL_verify_mode=>0
    ) or do{ dlog("SSL connect failed"); return ""; };
  } else {
    $sock = IO::Socket::INET->new(
      PeerHost=>$host,
      PeerPort=>$port,
      Timeout=>$TIMEOUT
    ) or do{ dlog("TCP connect failed"); return ""; };
  }

  my $req = "GET $path $http_proto\r\n".
            "Host: $host\r\n".
            "User-Agent: Mozilla/5.0 (FeedFetch/$VERSION)\r\n".
            "Accept: application/rss+xml,application/atom+xml,application/xml;q=0.9,text/xml;q=0.8,*/*;q=0.7\r\n".
            "Accept-Encoding: gzip,deflate\r\n".
            ($force_http10?"":"TE: chunked\r\n").
            "Connection: close\r\n\r\n";

  print $sock $req;
  my $res = ""; while(<$sock>){ $res .= $_; } close $sock;

  my ($h,$b);
  if($res =~ /(.*?)\r?\n\r?\n(.*)/s) { $h=$1; $b=$2; }
  else { dlog("Header/body split failed"); return ""; }

  dlog("--- HEADERS ---\n$h\n---------------------");

  if($h =~ /^location\s*:\s*([^\n]+)/im){
    my $l=$1; $l=~s/\s+$//;
    dlog("Redirect => $l");
    if($l =~ m|^https?://|i){ return fetch_http($l,$depth+1,http10_hint($l)); }
    elsif($l =~ m|^/|){ my $scheme=$is_https?'https':'http'; return fetch_http("$scheme://$host$l",$depth+1,http10_hint("$scheme://$host$l")); }
  }

  if($h =~ /Transfer-Encoding:\s*chunked/i) {
      my $decoded = decode_chunked($b);
      if(defined $decoded){ $b = $decoded; dlog("Chunked decoded len=".length($b)); }
  }
  if($h =~ /Content-Encoding:\s*gzip/i) {
      my $decoded = decode_gzip($b);
      if(defined $decoded){ $b = $decoded; dlog("Gzip decoded len=".length($b)); }
  }
  elsif($h =~ /Content-Encoding:\s*deflate/i) {
      my $decoded = decode_deflate($b);
      if(defined $decoded){ $b = $decoded; dlog("Deflate decoded len=".length($b)); }
  }

  return $b || "";
}

sub decode_chunked {
  my ($p)=@_; my $out="";
  while($p =~ s/^([0-9A-Fa-f]+)\r?\n//s){
    my $len = hex($1);
    last if $len == 0;
    return undef if length($p) < $len;
    $out .= substr($p,0,$len);
    $p = substr($p,$len);
    $p =~ s/^\r?\n//;
  }
  return $out;
}

sub decode_gzip {
  my ($b)=@_;
  eval {
    require IO::Uncompress::Gunzip;
    my $out = "";
    IO::Uncompress::Gunzip::gunzip(\$b => \$out)
        or die $IO::Uncompress::Gunzip::GunzipError;
    $b = $out;
  };
  if($@ || $b eq "") {
    eval {
      require Compress::Raw::Zlib;
      my ($i) = Compress::Raw::Zlib::inflateInit(-WindowBits=>47);
      my $o=""; $i->inflate($b,$o); $b=$o if length $o;
    };
  }
  return $b;
}

sub decode_deflate {
  my ($b)=@_;
  eval {
    require Compress::Raw::Zlib;
    my ($i)=Compress::Raw::Zlib::inflateInit();
    my $o=""; $i->inflate($b,$o); $b=$o;
  };
  return $@ ? undef : $b;
}

sub detect_format {
  my ($x)=@_;
  return 'rss'  if $x =~ /<rss\b/i;
  return 'atom' if $x =~ /<feed\b/i;
  return 'rdf'  if $x =~ /<rdf:RDF\b/i;
  return 'unknown';
}

sub parse_rss {
  my ($x)=@_;
  my ($t)=$x=~m|<channel[^>]*>.*?<title[^>]*>(.*?)</title>|is;
  $t=clean($t)||"RSS Feed";
  my @i;
  while($x =~ m|<item[^>]*>(.*?)</item>|sig){
    my $b=$1;
    my ($ti)=$b=~m|<title[^>]*>(.*?)</title>|is;
    my ($l) =$b=~m|<link[^>]*>(.*?)</link>|is;
    next unless $ti && $l;
    push @i, {title=>clean($ti), link=>clean($l)};
    last if @i >= $MAX_ITEMS;
  }
  return ($t,@i);
}

sub parse_atom {
  my ($x)=@_;
  my ($t)=$x=~m|<feed[^>]*>.*?<title[^>]*>(.*?)</title>|is;
  $t=clean($t)||"Atom Feed";
  my @i;
  while($x =~ m|<entry[^>]*>(.*?)</entry>|sig){
    my $b=$1;
    my ($ti)=$b=~m|<title[^>]*>(.*?)</title>|is;
    my $l='';
    ($l)=$b=~m|<link[^>]*\brel=['"]alternate['"][^>]*\bhref=['"]([^'"]+)|i;
    $l||=($b=~m|<link[^>]*\btype=['"]text/html['"][^>]*\bhref=['"]([^'"]+)|i)?$1:'';
    $l||=($b=~m|<link[^>]*\bhref=['"]([^'"]+)|i)?$1:'';
    next unless $ti && $l;
    push @i, {title=>clean($ti), link=>clean($l)};
    last if @i >= $MAX_ITEMS;
  }
  return ($t,@i);
}

sub parse_rdf {
  my ($x)=@_;
  my ($t)=$x=~m|<channel[^>]*>.*?<title[^>]*>(.*?)</title>|is;
  $t=clean($t)||"RDF Feed";
  my @i;
  while($x =~ m|<item[^>]*>(.*?)</item>|sig){
    my $b=$1;
    my ($ti)=$b=~m|<title[^>]*>(.*?)</title>|is;
    my ($l) =$b=~m|<link[^>]*>(.*?)</link>|is;
    next unless $ti && $l;
    push @i, {title=>clean($ti), link=>clean($l)};
    last if @i >= $MAX_ITEMS;
  }
  return ($t,@i);
}

sub output_html {
  my ($t,@i)=@_;
  print "<div style='height:$BOX_HEIGHT;font-family:$FONT_FAMILY;font-size:$FONT_SIZE;background:$BOX_BG;border:$BOX_BORDER;padding:$BOX_PADDING;box-sizing:border-box;'>\n";
  print "<h3 style='margin:0 0 4px 0;'>$t</h3>\n";
  if(!@i){ print "<i>No headlines found.</i>\n"; }
  else {
    print "<ul style='list-style:none;padding-left:10px;margin:0;'>\n";
    for(@i){
      print "<li style='margin:0.2em 0;'><a href='$_->{link}' target='_blank' ".
           "style='color:$LINK_COLOR;text-decoration:none;' ".
           "onmouseover=\"this.style.textDecoration='$LINK_HOVER'\" ".
           "onmouseout=\"this.style.textDecoration='none'\">$_->{title}</a></li>\n";
    }
    print "</ul>\n";
  }
  print "</div>\n";
}

sub clean {
  my $t=shift//'';
  $t =~ s/<!\[CDATA\[//g; $t =~ s/\]\]>//g;
  $t =~ s/<[^>]+>//g;
  $t =~ s/&lt;/</g; $t =~ s/&gt;/>/g; $t =~ s/&amp;/&/g;
  $t =~ s/&apos;/'/g; $t =~ s/&quot;/"/g;
  $t =~ s/^\s+|\s+$//g;
  return $t;
}
