FeedFetch v1.0 - Lightweight Server-Side RSS Reader
====================================================

Overview
--------
FeedFetch is a single Perl CGI script that retrieves RSS or Atom feeds
directly from your web server and outputs simple, styled HTML headlines.
It works entirely server-side and requires no JavaScript or external proxies.

Requirements
------------
* Perl 5.x
* Core modules: Socket, IO::Socket::INET, URI::Escape
* Optional: IO::Socket::SSL, Net::SSLeay for HTTPS feed support

Installation
------------
1. Copy files to your web directory:
   feedfetch.pl  ->  /path/to/public_html/
   index.html    ->  /path/to/public_html/

2. Make the script executable:
   chmod 755 feedfetch.pl

3. Enable CGI execution in Apache or lighttpd configuration:
   Options +ExecCGI
   AddHandler cgi-script .pl

4. Test in browser:
   https://yourdomain.com/feedfetch.pl?url=http://rss.cnn.com/rss/edition.rss

Configuration
-------------
Edit feedfetch.pl and modify values in the CONFIGURATION SECTION.

Key options:
  $MAX_ITEMS        Number of headlines per feed (default 15)
  $TIMEOUT          Socket timeout in seconds (default 15)
  $FONT_FAMILY      Font family (default "sans-serif")
  $FONT_SIZE        Base text size (default "90%")
  $BOX_BORDER       Feed box border style
  $BOX_BG           Background color
  $LINK_COLOR       Link color
  $LINK_HOVER       Hover effect ("underline" or "none")

Usage
-----
Include the script in your web pages using iframes.
Example (see index.html):

  <iframe src="feedfetch.pl?url=http://rss.cnn.com/rss/edition.rss"
          width="100%" height="600" frameborder="0"></iframe>

Adding More Feeds
-----------------
To add more feeds, open index.html and duplicate one of the <td> blocks:

  <td><iframe src="feedfetch.pl?url=YOUR_FEED_URL"
              width="100%" height="600" frameborder="0"></iframe></td>

Adjust the width or height as desired for your layout.
You can create multiple rows of feeds by adding more <tr>...</tr> blocks.

License
-------
This script is provided free for personal or non-commercial use.
No warranty is provided. Use at your own discretion.
