#!/usr/bin/perl
# ============================================================
# feedfetch.pl — Fetch and render a single RSS/Atom feed
# ------------------------------------------------------------
# DESCRIPTION:
#   Fetches one RSS/Atom feed and outputs a simple, styled HTML list.
#   Works with both HTTP and HTTPS. Follows one redirect (301/302).
#   Designed for use in <iframe> or included in larger pages.
#
# REQUIRED PERL MODULES:
#   use Socket;             # (core)
#   use IO::Socket::INET;   # (core)
#   use URI::Escape;        # (core)
#
# OPTIONAL MODULES:
#   use IO::Socket::SSL;    # Enables HTTPS support
#
# USAGE:
#   feedfetch.pl?url=https://example.com/feed.xml
#
# VERSION:  1.0
# ============================================================

use strict;
use warnings;
use Socket;
use IO::Socket::INET;
eval { require IO::Socket::SSL };
use URI::Escape;

# ============================================================
# CONFIGURATION SECTION
# ============================================================

my $MAX_ITEMS  = 15;
my $TIMEOUT    = 15;
my $FOLLOW_REDIRECTS = 1;

my $FONT_FAMILY  = "sans-serif";
my $FONT_SIZE    = "90%";
my $BOX_BORDER   = "1px solid #ccc";
my $BOX_BG       = "#f9f9f9";
my $BOX_RADIUS   = "6px";
my $BOX_PADDING  = "0.8em";
my $BOX_MARGIN   = "0.8em";
my $TITLE_COLOR  = "#222";
my $LINK_COLOR   = "#003366";
my $LINK_HOVER   = "underline";
my $BULLET_STYLE = "square";

# ============================================================

my $query = $ENV{'QUERY_STRING'} // '';
my $url   = '';
if ( $query =~ /url=([^&]+)/ ) {
    $url = uri_unescape($1);
}

print "Content-Type: text/html; charset=utf-8\n\n";

unless ( $url =~ m{^https?://} ) {
    print "<p><b>Error:</b> invalid ?url= parameter</p>\n";
    exit;
}

my $body = fetch_url($url, 0);
if ( !$body ) {
    print "<div style='font-family:$FONT_FAMILY;font-size:$FONT_SIZE;
           border:$BOX_BORDER;padding:$BOX_PADDING;margin:$BOX_MARGIN;
           background:$BOX_BG;border-radius:$BOX_RADIUS;'>
           <h3 style='margin-top:0;font-size:1em;'>$url</h3>
           <p>No data received.</p></div>\n";
    exit;
}

my @titles;
while ( $body =~ m{<item>.*?<title>(.*?)</title>.*?
                   (?:<link>(.*?)</link>|<link\s+[^>]*href=['"](.*?)['"][^>]*>)
                   .*?</item>}sigx ) {
    my ($t, $l) = ($1, $2 || $3 || "#");
    $t =~ s/<!\[CDATA\[//g; $t =~ s/\]\]>//g;
    push @titles, [$t, $l];
}
if ( !@titles ) {
    while ( $body =~ m{<entry>.*?<title>(.*?)</title>.*?
                       (?:<link>(.*?)</link>|<link\s+[^>]*href=['"](.*?)['"][^>]*>)
                       .*?</entry>}sigx ) {
        my ($t, $l) = ($1, $2 || $3 || "#");
        $t =~ s/<!\[CDATA\[//g; $t =~ s/\]\]>//g;
        push @titles, [$t, $l];
    }
}

print qq{
<div class="feedbox" style="
     font-family:$FONT_FAMILY;font-size:$FONT_SIZE;
     border:$BOX_BORDER;border-radius:$BOX_RADIUS;
     background:$BOX_BG;padding:$BOX_PADDING;margin:$BOX_MARGIN;">
  <h3 style="margin:0 0 0.4em 0;font-size:1em;color:$TITLE_COLOR;
             border-bottom:1px solid #ddd;padding-bottom:0.3em;">
    $url
  </h3>
  <ul style="list-style-type:$BULLET_STYLE;margin:0;padding-left:1.2em;">
};

my $count = 0;
for my $it (@titles) {
    last if ++$count > $MAX_ITEMS;
    my ($t, $l) = @$it;
    $t =~ s/[<>]/ /g;
    print qq{  <li style="margin-bottom:0.3em;">
                 <a href="$l" target="_blank"
                    style="color:$LINK_COLOR;text-decoration:none;"
                    onmouseover="this.style.textDecoration='$LINK_HOVER';"
                    onmouseout="this.style.textDecoration='none';">
                    $t
                 </a>
              </li>\n};
}
print "</ul></div>\n";
exit 0;

sub fetch_url {
    my ( $url, $depth ) = @_;
    return if $depth > $FOLLOW_REDIRECTS;
    my ( $scheme, $host, $path ) = $url =~ m{^(https?)://([^/]+)(.*)$};
    $path ||= "/";
    my $port = ( $host =~ s/:(\d+)$// ) ? $1 : ( $scheme eq "https" ? 443 : 80 );

    my $sock;
    if ( $scheme eq "https" && eval { IO::Socket::SSL->can('start_SSL') } ) {
        $sock = IO::Socket::INET->new(
            PeerHost => $host, PeerPort => $port,
            Proto    => "tcp", Timeout  => $TIMEOUT
        ) or return;
        IO::Socket::SSL->start_SSL( $sock, SSL_verify_mode => 0 ) or return;
    }
    else {
        $sock = IO::Socket::INET->new(
            PeerHost => $host, PeerPort => $port,
            Proto    => "tcp", Timeout  => $TIMEOUT
        ) or return;
    }

    print $sock join(
        "\r\n",
        "GET $path HTTP/1.1",
        "Host: $host",
        "User-Agent: Mozilla/5.0 (FeedFetch/1.0)",
        "Accept: text/xml,application/rss+xml,application/atom+xml,*/*;q=0.9",
        "Accept-Encoding: identity",
        "Connection: close",
        "", ""
    );

    my $raw = '';
    while (<$sock>) { $raw .= $_; }
    close($sock);

    my ( $headers, $body ) = split( /\r?\n\r?\n/, $raw, 2 );
    return unless $headers;

    if ( $headers =~ m{^HTTP/\S+\s+30[123]} && $headers =~ m{Location:\s*(\S+)}i ) {
        my $redir = $1;
        $redir =~ s/\r|\n//g;
        return fetch_url( $redir, $depth + 1 );
    }
    return $body;
}
